SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `zf2_angular` DEFAULT CHARACTER SET latin1 ;
USE `zf2_angular` ;

-- -----------------------------------------------------
-- Table `zf2_angular`.`categorias`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `zf2_angular`.`categorias` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `nome` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

use zf2_categorias;

insert into categorias (nome) values ('Games');
insert into categorias (nome) values ('Celulares');